""" A collection of CLI execution tools """
