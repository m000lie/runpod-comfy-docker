""" Allows for the creation of mutations in the GraphQL API. """
