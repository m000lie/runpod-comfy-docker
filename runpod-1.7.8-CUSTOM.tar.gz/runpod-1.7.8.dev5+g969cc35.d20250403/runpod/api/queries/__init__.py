""" Allows queries to be imported as a module."""
