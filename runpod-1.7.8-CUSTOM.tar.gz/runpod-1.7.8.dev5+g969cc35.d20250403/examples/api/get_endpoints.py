""" Get all endpoints from the API """

import runpod

endpoints = runpod.get_endpoints()

print(endpoints)
