""" Allows tests to be imported as a module."""

import sys

sys.path.append("src")
