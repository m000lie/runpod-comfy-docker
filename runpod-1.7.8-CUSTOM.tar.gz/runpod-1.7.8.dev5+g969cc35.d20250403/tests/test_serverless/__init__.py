""" Alow serverless tests to be run from the command line."""
