""" Allow CLI groups to be tested. """
