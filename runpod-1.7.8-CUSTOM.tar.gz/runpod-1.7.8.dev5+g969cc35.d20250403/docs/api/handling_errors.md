# Handling Errors

```Python
import runpod

try:
    # Use runpod to make a request
except runpod.error.AuthenticationError as err:
    # Authentication with the API failed
```
